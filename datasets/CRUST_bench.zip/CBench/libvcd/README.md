# libvcd

a C library for parsing Value Change Dump `.vcd` files.
