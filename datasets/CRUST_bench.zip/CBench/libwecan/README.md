# libwecan

Library in C to encode/decode CAN signals.

### Install
```sh
make
make run-tests
```
