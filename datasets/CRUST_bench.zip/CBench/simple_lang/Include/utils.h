//
// Created by lixiaobai on 24-7-6.
//

#ifndef SIMPLE_LANG_UTILS_H
#define SIMPLE_LANG_UTILS_H

#ifdef _WIN32
char *strndup(const char *s, size_t n);
#endif

#endif //SIMPLE_LANG_UTILS_H
