#ifndef SIMPLE_LANG_LEXER_H
#define SIMPLE_LANG_LEXER_H

#include "token.h"

Token* tokenize(const char* source);

#endif //SIMPLE_LANG_LEXER_H
