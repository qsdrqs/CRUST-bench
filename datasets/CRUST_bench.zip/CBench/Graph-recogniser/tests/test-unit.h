#if !defined UNIT_TEST
#define UNIT_TEST

int test_openhash();
int test_cuckoohash();

#endif /* !UNIT_TEST */

