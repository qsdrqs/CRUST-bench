# HAMTa - Hash Array Mapped Trie

* implementation in C
* architecture dependent build (32bit and 64bit)
* Cython wrapper included (only for ints now)
* tested on armv7 32bit Chromebook
    * Performance is not better than python dict timewise nor memorywise
