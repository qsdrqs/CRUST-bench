
#pragma once

#include <stdbool.h>

void do_assert(bool cond);
