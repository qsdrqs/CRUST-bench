
#pragma once

#include "trusted_utils.h"

void confirm_result(u8* f_sig, u8 constant, u8* out);
