#ifndef MATRIX_TEST_H
#define MATRIX_TEST_H

#ifdef __cplusplus
extern "C" {
#endif

int run_matrix_tests();

#ifdef __cplusplus
}
#endif

#endif
