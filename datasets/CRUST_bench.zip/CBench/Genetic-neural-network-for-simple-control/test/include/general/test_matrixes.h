#ifndef TEST_MATRIXES_H
#define TEST_MATRIXES_H

// function to test matrix add and sub
int testMatrixAddSub();

// function to test matrix multiply
int testMatrixMultiply();

// function to test matrix act fnc multiplication
int testMatrixAllValuesFormula();

// functon to test creatio og matrixes from pointer
int testMatrixCreateFromPointer();

// function to test the fully copy of the materix
int testMatrixFullyCoppyMatrix();
#endif