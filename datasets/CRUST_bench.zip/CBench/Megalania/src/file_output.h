#pragma once
#include "output_interface.h"
#include <stdio.h>

//provides an interface for writing to a file object

void file_output_new(OutputInterface* output, FILE* file);
