# MEGALANIA

## Sometimes, you just need a big lizard

Megalania is an LZMA compressor that uses simulated annealing to find an optimal sequence of LZMA packets to maximize the compression ratio. It's very slow, but if given time it might compress better than xzutils can.

This is still a work in progress.
