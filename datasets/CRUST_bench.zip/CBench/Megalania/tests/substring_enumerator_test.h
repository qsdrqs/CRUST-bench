#pragma once

void substring_enumerator_test();
