use crate::tisp::{Rec, Tsp, Val};
pub fn prim_car(st: &mut Tsp, env: &mut Rec, args: Val) -> Val {
    unimplemented!()
}
pub fn prim_cdr(st: &mut Tsp, env: &mut Rec, args: Val) -> Val {
    unimplemented!()
}
pub fn prim_cons(st: &mut Tsp, env: &mut Rec, args: Val) -> Val {
    unimplemented!()
}
pub fn form_quote(st: &mut Tsp, env: &mut Rec, args: Val) -> Val {
    unimplemented!()
}
pub fn prim_eval(st: &mut Tsp, env: &mut Rec, args: Val) -> Val {
    unimplemented!()
}
pub fn prim_eq(st: &mut Tsp, env: &mut Rec, args: Val) -> Val {
    unimplemented!()
}
pub fn form_cond(st: &mut Tsp, env: &mut Rec, args: Val) -> Val {
    unimplemented!()
}
pub fn prim_typeof(st: &mut Tsp, env: &mut Rec, args: Val) -> Val {
    unimplemented!()
}
pub fn prim_procprops(st: &mut Tsp, env: &mut Rec, args: Val) -> Val {
    unimplemented!()
}
pub fn form_Func(st: &mut Tsp, env: &mut Rec, args: Val) -> Val {
    unimplemented!()
}
pub fn form_Macro(st: &mut Tsp, env: &mut Rec, args: Val) -> Val {
    unimplemented!()
}
pub fn prim_error(st: &mut Tsp, env: &mut Rec, args: Val) -> Val {
    unimplemented!()
}
pub fn prim_recmerge(st: &mut Tsp, env: &mut Rec, args: Val) -> Val {
    unimplemented!()
}
pub fn prim_records(st: &mut Tsp, env: &mut Rec, args: Val) -> Val {
    unimplemented!()
}
pub fn form_def(st: &mut Tsp, env: &mut Rec, args: Val) -> Val {
    unimplemented!()
}
pub fn form_undefine(st: &mut Tsp, env: &mut Rec, args: Val) -> Val {
    unimplemented!()
}
pub fn form_definedp(st: &mut Tsp, env: &mut Rec, args: Val) -> Val {
    unimplemented!()
}
pub fn tib_env_core(st: &mut Tsp) {
    unimplemented!()
}