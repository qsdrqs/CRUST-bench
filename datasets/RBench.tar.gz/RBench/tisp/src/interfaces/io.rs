use crate::tisp::{Tsp, Val, Rec};
pub fn count_parens(s: &str, len: i32) -> i32 {
unimplemented!()
}
pub fn read_file(fname: &str) -> String {
unimplemented!()
}
pub fn prim_write(st: &mut Tsp, env: &mut Rec, args: Val) -> Val {
unimplemented!()
}
pub fn prim_read(st: &mut Tsp, env: &mut Rec, args: Val) -> Val {
unimplemented!()
}
pub fn prim_parse(st: &mut Tsp, env: &mut Rec, args: Val) -> Val {
unimplemented!()
}
pub fn prim_load(st: &mut Tsp, env: &mut Rec, args: Val) -> Val {
unimplemented!()
}
pub fn tib_env_io(st: &mut Tsp) {
unimplemented!()
}