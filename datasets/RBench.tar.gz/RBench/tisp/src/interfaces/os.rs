use crate::tisp::{Tsp, Val, Rec};
pub fn prim_cd(st: &mut Tsp, env: &mut Rec, args: Val) -> Val {
unimplemented!()
}
pub fn prim_pwd(st: &mut Tsp, env: &mut Rec, args: Val) -> Val {
unimplemented!()
}
pub fn prim_exit(st: &mut Tsp, env: &mut Rec, args: Val) -> Val {
unimplemented!()
}
pub fn prim_now(st: &mut Tsp, env: &mut Rec, args: Val) -> Val {
unimplemented!()
}
pub fn form_time(st: &mut Tsp, env: &mut Rec, args: Val) -> Val {
unimplemented!()
}
pub fn tib_env_os(st: &mut Tsp) {
unimplemented!()
}