/// Encode the given source bytes into base62. Returns the number of written bytes on success.
pub fn base62_encode(_src: &[u8], _out: &mut [u8]) -> Option<usize> {
    unimplemented!()
}
/// Encode the given source bytes into base64. Returns the number of written bytes on success.
pub fn base64_encode(_src: &[u8], _out: &mut [u8]) -> Option<usize> {
    unimplemented!()
}
/// Decode the given base64-encoded source bytes. Returns the number of decoded bytes on success.
pub fn base64_decode(_src: &[u8], _out: &mut [u8]) -> Option<usize> {
    unimplemented!()
}