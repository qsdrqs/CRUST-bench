use rand::seq::SliceRandom;
use rand::thread_rng;
use crate::cards::{Card, RANKS_PER_DECK, SUITS_PER_DECK, Rank, Suit};
pub const CARDS_PER_DECK: usize = 52;
pub fn new_deck() -> Vec<Card> {
    unimplemented!()
}
pub fn deck_shuffle(deck: &mut Vec<Card>) {
    unimplemented!()
}