pub fn pack0_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
unimplemented!()
}
pub fn pack0_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
unimplemented!()
}
pub fn pack0_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
unimplemented!()
}
pub fn unpack0_32(base: u32, input: &[u8], output: &mut [u32]) -> u32 {
unimplemented!()
}
pub fn unpack0_16(base: u32, input: &[u8], output: &mut [u32]) -> u32 {
unimplemented!()
}
pub fn unpack0_8(base: u32, input: &[u8], output: &mut [u32]) -> u32 {
unimplemented!()
}
pub fn pack0_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
unimplemented!()
}
pub fn unpack0_x(base: u32, input: &[u8], output: &mut [u32], length: u32) -> u32 {
unimplemented!()
}
pub fn linsearch0_32(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
unimplemented!()
}
pub fn linsearch0_16(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
unimplemented!()
}
pub fn linsearch0_8(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
unimplemented!()
}
pub fn linsearch0_x(base: u32, input: &[u8], length: u32, value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn pack1_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack2_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack3_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack4_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack5_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack6_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack7_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack8_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack9_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack10_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack11_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack12_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack13_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack14_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack15_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack16_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack17_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack18_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack19_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack20_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack21_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack22_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack23_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack24_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack25_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack26_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack27_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack28_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack29_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack30_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack31_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack32_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack1_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack2_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack3_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack4_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack5_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack6_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack7_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack8_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack9_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack10_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack11_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack12_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack13_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack14_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack15_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack16_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack17_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack18_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack19_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack20_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack21_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack22_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack23_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack24_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack25_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack26_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack27_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack28_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack29_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack30_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack31_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack32_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack1_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack2_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack3_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack4_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack5_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack6_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack7_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack8_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack9_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack10_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack11_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack12_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack13_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack14_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack15_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack16_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack17_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack18_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack19_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack20_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack21_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack22_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack23_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack24_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack25_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack26_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack27_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack28_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack29_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack30_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack31_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack32_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack1_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack2_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack3_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack4_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack5_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack6_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack7_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack8_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack9_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack10_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack11_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack12_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack13_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack14_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack15_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack16_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack17_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack18_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack19_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack20_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack21_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack22_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack23_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack24_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack25_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack26_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack27_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack28_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack29_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack30_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack31_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack32_8(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack1_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack2_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack3_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack4_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack5_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack6_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack7_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack8_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack9_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack10_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack11_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack12_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack13_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack14_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack15_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack16_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack17_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack18_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack19_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack20_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack21_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack22_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack23_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack24_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack25_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack26_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack27_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack28_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack29_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack30_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack31_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack32_16(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack1_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack2_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack3_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack4_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack5_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack6_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack7_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack8_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack9_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack10_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack11_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack12_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack13_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack14_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack15_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack16_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack17_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack18_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack19_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack20_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack21_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack22_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack23_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack24_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack25_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack26_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack27_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack28_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack29_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack30_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack31_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn unpack32_32(base: u32, input: &[u32], output: &mut [u8]) -> u32 {
    unimplemented!()
}
pub fn pack1_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn pack2_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn pack3_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn pack4_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn pack5_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn pack6_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn pack7_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn pack8_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn pack9_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn pack10_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn pack11_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn pack12_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn pack13_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn pack14_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn pack15_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn pack16_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn pack17_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn pack18_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn pack19_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn pack20_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn pack21_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn pack22_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn pack23_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn pack24_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn pack25_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn pack26_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn pack27_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn pack28_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn pack29_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn pack30_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn pack31_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn pack32_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn unpack1_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn unpack2_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn unpack3_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn unpack4_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn unpack5_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn unpack6_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn unpack7_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn unpack8_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn unpack9_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn unpack10_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn unpack11_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn unpack12_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn unpack13_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn unpack14_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn unpack15_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn unpack16_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn unpack17_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn unpack18_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn unpack19_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn unpack20_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn unpack21_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn unpack22_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn unpack23_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn unpack24_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn unpack25_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn unpack26_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn unpack27_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn unpack28_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn unpack29_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn unpack30_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn unpack31_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn unpack32_x(base: u32, input: &[u32], output: &mut [u8], length: u32) -> u32 {
    unimplemented!()
}
pub fn linsearch1_32(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch2_32(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch3_32(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch4_32(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch5_32(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch6_32(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch7_32(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch8_32(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch9_32(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch10_32(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch11_32(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch12_32(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch13_32(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch14_32(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch15_32(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch16_32(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch17_32(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch18_32(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch19_32(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch20_32(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch21_32(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch22_32(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch23_32(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch24_32(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch25_32(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch26_32(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch27_32(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch28_32(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch29_32(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch30_32(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch31_32(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch32_32(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch1_16(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch2_16(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch3_16(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch4_16(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch5_16(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch6_16(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch7_16(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch8_16(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch9_16(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch10_16(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch11_16(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch12_16(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch13_16(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch14_16(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch15_16(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch16_16(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch17_16(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch18_16(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch19_16(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch20_16(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch21_16(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch22_16(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch23_16(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch24_16(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch25_16(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch26_16(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch27_16(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch28_16(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch29_16(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch30_16(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch31_16(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch32_16(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch1_8(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch2_8(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch3_8(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch4_8(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch5_8(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch6_8(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch7_8(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch8_8(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch9_8(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch10_8(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch11_8(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch12_8(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch13_8(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch14_8(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch15_8(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch16_8(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch17_8(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch18_8(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch19_8(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch20_8(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch21_8(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch22_8(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch23_8(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch24_8(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch25_8(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch26_8(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch27_8(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch28_8(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch29_8(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch30_8(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch31_8(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch32_8(base: u32, input: &[u8], value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch1_x(base: u32, input: &[u8], length: u32, value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch2_x(base: u32, input: &[u8], length: u32, value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch3_x(base: u32, input: &[u8], length: u32, value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch4_x(base: u32, input: &[u8], length: u32, value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch5_x(base: u32, input: &[u8], length: u32, value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch6_x(base: u32, input: &[u8], length: u32, value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch7_x(base: u32, input: &[u8], length: u32, value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch8_x(base: u32, input: &[u8], length: u32, value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch9_x(base: u32, input: &[u8], length: u32, value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch10_x(base: u32, input: &[u8], length: u32, value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch11_x(base: u32, input: &[u8], length: u32, value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch12_x(base: u32, input: &[u8], length: u32, value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch13_x(base: u32, input: &[u8], length: u32, value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch14_x(base: u32, input: &[u8], length: u32, value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch15_x(base: u32, input: &[u8], length: u32, value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch16_x(base: u32, input: &[u8], length: u32, value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch17_x(base: u32, input: &[u8], length: u32, value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch18_x(base: u32, input: &[u8], length: u32, value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch19_x(base: u32, input: &[u8], length: u32, value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch20_x(base: u32, input: &[u8], length: u32, value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch21_x(base: u32, input: &[u8], length: u32, value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch22_x(base: u32, input: &[u8], length: u32, value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch23_x(base: u32, input: &[u8], length: u32, value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch24_x(base: u32, input: &[u8], length: u32, value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch25_x(base: u32, input: &[u8], length: u32, value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch26_x(base: u32, input: &[u8], length: u32, value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch27_x(base: u32, input: &[u8], length: u32, value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch28_x(base: u32, input: &[u8], length: u32, value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch29_x(base: u32, input: &[u8], length: u32, value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch30_x(base: u32, input: &[u8], length: u32, value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch31_x(base: u32, input: &[u8], length: u32, value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}
pub fn linsearch32_x(base: u32, input: &[u8], length: u32, value: u32, found: &mut i32) -> u32 {
    unimplemented!()
}