pub const ARG_INIT: &str = "init";
pub const ARG_HELP: &str = "--help";
pub const ARG_HELP_SC: &str = "-h";
pub const ARG_ADD_CHANGES: &str = "add";
pub const ARG_COMMIT: &str = "commit";
pub const ARG_ROLLBACK: &str = "rollback";
pub fn main() {
    unimplemented!()
}
pub fn getting_help() {
    unimplemented!()
}
pub fn init_repository() {
    unimplemented!()
}
pub fn track_changes(n: i32, files: &Vec<&str>) {
    unimplemented!()
}
pub fn commit_changes() {
    unimplemented!()
}
pub fn rollback_changes(hash: &str) {
    unimplemented!()
}