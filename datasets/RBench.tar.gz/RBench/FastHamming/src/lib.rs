pub mod fast_hamming;
