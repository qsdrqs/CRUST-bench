// Define the Morton struct
pub struct Morton {
    pub lo: u32,
    pub hi: u32,
}
// Function Declarations
pub fn unmortoner(x: u64) -> u32 {
    unimplemented!()
}
pub fn morton(hi: u32, lo: u32) -> u64 {
    unimplemented!()
}