pub mod hash;
pub mod heap;
pub mod rubik_model;
pub mod solve_rubik;
