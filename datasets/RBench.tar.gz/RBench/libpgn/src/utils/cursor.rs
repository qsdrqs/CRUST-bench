fn pgn_cursor_skip_whitespace(s: &str, cursor: &mut usize) -> bool {
    unimplemented!()
}

fn pgn_cursor_revisit_whitespace(s: &str, cursor: &mut usize) -> bool {
    unimplemented!()
}

fn pgn_cursor_skip_comment(s: &str, cursor: &mut usize) -> bool {
    unimplemented!()
}

fn pgn_cursor_skip_newline(s: &str, cursor: &mut usize) -> bool {
    unimplemented!()
}
