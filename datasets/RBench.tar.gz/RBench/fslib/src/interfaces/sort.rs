use crate::fst::{Fst,ArcData};
use std::cmp::Ordering;
fn icomp(a: &ArcData, b: &ArcData) -> std::cmp::Ordering {
    unimplemented!()
}
fn ocomp(a: &ArcData, b: &ArcData) -> std::cmp::Ordering {
    unimplemented!()
}
pub fn fst_arc_sort(fst: &mut Fst, sort_outer: bool) {
    unimplemented!()
}