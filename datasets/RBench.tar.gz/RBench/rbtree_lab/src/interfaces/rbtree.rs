use std::cell::RefCell;
use std::rc::Rc;
#[derive(Debug, PartialEq, Clone)]
pub enum Color {
    Red,
    Black,
}
type NodeRef = Rc<RefCell<Node>>;
pub type Key = i32;
#[derive(Debug, Clone)]
pub struct Node {
    pub key: i32,
    pub color: Color,
    pub left: Option<NodeRef>,
    pub right: Option<NodeRef>,
    pub parent: Option<NodeRef>, // Safe reference to the parent
}
#[derive(Debug, Clone)]
pub struct RBTree {
    pub root: NodeRef,
    pub nil: NodeRef,
}
impl RBTree {
    pub fn new() -> Self {
        unimplemented!()
    }
    /// Performs a right rotation around node `x`
    pub fn right_rotate(&mut self, x: NodeRef) {
        unimplemented!()
    }
    /// Performs a left rotation around node `x`
    pub fn left_rotate(&mut self, x: NodeRef) {
        unimplemented!()
    }
    pub fn free_node(node: Option<NodeRef>) {
        unimplemented!()
    }
    /// **Deletes the Red-Black Tree safely**
    pub fn delete_rbtree(self) {
        unimplemented!()
    }
    /// Fixes the Red-Black Tree after insertion
    pub fn rbtree_insert_fixup(&mut self, mut z: NodeRef) {
        unimplemented!()
    }
    /// Inserts a new key into the Red-Black Tree
    pub fn rbtree_insert(&mut self, key: i32) -> Option<NodeRef> {
        unimplemented!()
    }
    pub fn rbtree_find(&self, key: i32) -> Option<NodeRef> {
        unimplemented!()
    }
    /// Finds the minimum node in the tree
    pub fn rbtree_min(&self) -> Option<NodeRef> {
        unimplemented!()
    }
    /// Finds the maximum node in the tree
    pub fn rbtree_max(&self) -> Option<NodeRef> {
        unimplemented!()
    }
    /// Replaces subtree rooted at `u` with subtree rooted at `v`
    pub fn transplant(&mut self, u: NodeRef, v: Option<NodeRef>) {
        unimplemented!()
    }
    pub fn delete_fixup(&mut self, mut x: NodeRef) {
        unimplemented!()
    }
    pub fn erase(&mut self, p: NodeRef) {
        unimplemented!()
    }
    pub fn subtree_to_array(&self, curr: NodeRef, arr: &mut Vec<i32>, n: usize, count: &mut usize) {
        unimplemented!()
    }
    pub fn to_array(&self, n: usize) -> Vec<i32> {
        unimplemented!()
    }
}