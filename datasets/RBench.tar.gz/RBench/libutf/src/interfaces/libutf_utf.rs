pub type Utf8 = u8;
pub type Utf16 = u16;
pub type Utf32 = u32;
pub type Latin1 = u8;
pub type Ascii = u8;
pub fn utf8_validate(data: &[Utf8]) -> bool {
unimplemented!()
}
pub fn utf8_length_from_utf16le(data: &[Utf16]) -> usize {
unimplemented!()
}
pub fn utf8_length_from_utf32(data: &[Utf32]) -> usize {
unimplemented!()
}
pub fn utf8_length_from_latin1(data: &[Latin1]) -> usize {
unimplemented!()
}
pub fn utf8_convert_to_utf16le(data: &[Utf8], result: &mut [Utf16]) -> usize {
unimplemented!()
}
pub fn utf8_convert_to_utf32(data: &[Utf8], result: &mut [Utf32]) -> usize {
unimplemented!()
}
pub fn utf8_convert_to_latin1(data: &[Utf8], result: &mut [Latin1]) -> usize {
unimplemented!()
}
pub fn utf16le_validate(data: &[Utf16]) -> bool {
unimplemented!()
}
pub fn utf16_length_from_utf8(data: &[Utf8]) -> usize {
unimplemented!()
}
pub fn utf16_length_from_utf32(data: &[Utf32]) -> usize {
unimplemented!()
}
pub fn utf16_length_from_latin1(data: &[Latin1]) -> usize {
unimplemented!()
}
pub fn utf16le_convert_to_utf8(data: &[Utf16], result: &mut [Utf8]) -> usize {
unimplemented!()
}
pub fn utf16le_convert_to_utf32(data: &[Utf16], result: &mut [Utf32]) -> usize {
unimplemented!()
}
pub fn utf16le_convert_to_latin1(data: &[Utf16], result: &mut [Latin1]) -> usize {
unimplemented!()
}
pub fn utf32_validate(data: &[Utf32]) -> bool {
unimplemented!()
}
pub fn utf32_length_from_utf8(data: &[Utf8]) -> usize {
unimplemented!()
}
pub fn utf32_length_from_utf16le(data: &[Utf16]) -> usize {
unimplemented!()
}
pub fn utf32_length_from_latin1(data: &[Latin1]) -> usize {
unimplemented!()
}
pub fn utf32_convert_to_utf8(data: &[Utf32], result: &mut [Utf8]) -> usize {
unimplemented!()
}
pub fn utf32_convert_to_utf16le(data: &[Utf32], result: &mut [Utf16]) -> usize {
unimplemented!()
}
pub fn utf32_convert_to_latin1(data: &[Utf32], result: &mut [Latin1]) -> usize {
unimplemented!()
}
pub fn latin1_length_from_utf8(data: &[Utf8]) -> usize {
unimplemented!()
}
pub fn latin1_length_from_utf16le(data: &[Utf16]) -> usize {
unimplemented!()
}
pub fn latin1_length_from_utf32(data: &[Utf32]) -> usize {
unimplemented!()
}
pub fn latin1_convert_to_utf8(data: &[Latin1], result: &mut [Utf8]) -> usize {
unimplemented!()
}
pub fn latin1_convert_to_utf16le(data: &[Latin1], result: &mut [Utf16]) -> usize {
unimplemented!()
}
pub fn latin1_convert_to_utf32(data: &[Latin1], result: &mut [Utf32]) -> usize {
unimplemented!()
}
pub fn ascii_validate(data: &[Ascii]) -> bool {
unimplemented!()
}