use emlang::em as em;
use emlang::parser as parser;
pub fn parse(path: &str) -> em::Program {
    unimplemented!()
}
pub fn usage(path: &str) {
    unimplemented!()
}
pub fn main(){}