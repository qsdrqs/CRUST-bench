fn strcpy_to_heap(s: &str) -> String {
    unimplemented!()
}