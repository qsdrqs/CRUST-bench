pub mod data;
pub mod em;
pub mod env;
pub mod parser;
pub mod stack;

pub mod utils;

pub fn parse(path: &str) -> em::Program {
    unimplemented!()
}

pub fn usage(path: &str) {
    unimplemented!()
}
