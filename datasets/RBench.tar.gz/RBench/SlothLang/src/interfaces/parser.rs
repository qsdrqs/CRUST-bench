use crate::{throw, slothvm};
use crate::slothvm::SlothProgram;
pub fn parse(filename: &str) -> Option<SlothProgram> {
    unimplemented!()
}
pub fn free_program(_program: Option<SlothProgram>) {
    unimplemented!()
}
pub fn readline(file: &std::fs::File) -> Option<String> {
    unimplemented!()
}
pub fn prog_len(file: &std::fs::File) -> usize {
    unimplemented!()
}