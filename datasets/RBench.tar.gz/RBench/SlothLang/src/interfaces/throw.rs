pub fn math_err(msg: &str) {
unimplemented!()
}
pub fn op_err(type_: &str, code: u8) {
unimplemented!()
}