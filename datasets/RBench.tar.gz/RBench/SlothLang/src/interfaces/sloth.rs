use crate::{parser, throw, slothvm, stack};
fn main() {
    unimplemented!()
}