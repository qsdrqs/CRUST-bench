pub fn rpl_vsnprintf(
    s: &mut String,
    n: usize,
    format: &str,
    args: &[&str],
) -> i32{
    unimplemented!()
}
pub fn fmtstr(
    s: &mut String,
    size: usize,
    value: &str,
    width: usize,
    precision: usize,
    flags: i32,
    ){
    unimplemented!()
}
pub fn fmtint(
    s: &mut String,
    size: usize,
    value: i32,
    width: usize,
    precision: usize,
    flags: i32,
    ){
    unimplemented!()
}
pub fn fmtflt(
    s: &mut String,
    size: usize,
    value: f64,
    width: usize,
    precision: usize,
    flags: i32,
    ){
    unimplemented!()
}
pub fn printsep(
    s: &mut String,
    size:usize){
    unimplemented!()
}
pub fn getnumsep(digits: i32) -> i32{
    unimplemented!()
}
pub fn getexponent(value: f64) -> i32{
    unimplemented!()
}
pub fn convert(
    value: usize, 
    buf: &mut String,
    base: usize,
    caps:usize){
    unimplemented!()
}
pub fn cast(value: f64)->i32{
    unimplemented!()
}
pub fn mypow10(exponent: i32)->f64{
    unimplemented!()
}
pub fn rpl_vasprintf(
    s: Vec<String>,
    format: &str,
    args: &[&str],
    ) -> i32{
    unimplemented!()
}
pub fn rpl_asprintf(
    s: &mut String,
    format: &str,
    args: &[&str],
    ) -> i32{
    unimplemented!()
}
pub fn main(){
    unimplemented!()
}