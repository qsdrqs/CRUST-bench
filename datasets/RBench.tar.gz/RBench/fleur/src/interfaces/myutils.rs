pub fn print_bin(n: u64) -> String {
    unimplemented!()
}