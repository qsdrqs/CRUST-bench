/// Entry point of the application.
/// In C, this was 'int main(void)'.
pub fn main() {
unimplemented!()
}