use crate::lzma_state::LZMAState;
use crate::output_interface::OutputInterface;
pub fn lzma_encode_header(lzma_state: &LZMAState, output: &mut dyn OutputInterface) {
    unimplemented!();
}