pub type Prob = u16;
pub const NUM_BIT_MODEL_TOTAL_BITS: u32 = 11;
pub const PROB_INIT_VAL: Prob = (1 << NUM_BIT_MODEL_TOTAL_BITS) / 2;