use crate::encoder_interface::EncoderInterface;
pub fn perplexity_encoder_new(enc: &mut dyn EncoderInterface, perplexity: &mut u64) {
    unimplemented!();
}