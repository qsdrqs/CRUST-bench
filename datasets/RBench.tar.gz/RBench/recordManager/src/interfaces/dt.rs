pub type Bool = bool;
pub const TRUE: Bool = true;
pub const FALSE: Bool = false;