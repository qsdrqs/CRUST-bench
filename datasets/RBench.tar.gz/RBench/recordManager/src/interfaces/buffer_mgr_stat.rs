use crate::buffer_mgr::{BM_BufferPool, BM_PageHandle};
pub fn print_pool_content(bm: &BM_BufferPool) {
unimplemented!()
}
pub fn print_page_content(page: &BM_PageHandle) {
unimplemented!()
}
pub fn sprint_pool_content(bm: &BM_BufferPool) -> String {
unimplemented!()
}
pub fn sprint_page_content(page: &BM_PageHandle) -> String {
unimplemented!()
}
pub fn print_strat(bm: &BM_BufferPool) {
unimplemented!()
}