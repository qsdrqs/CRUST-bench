pub fn beaufort_tableau(alpha: &str) -> Vec<Vec<u8>> {
    unimplemented!()
}