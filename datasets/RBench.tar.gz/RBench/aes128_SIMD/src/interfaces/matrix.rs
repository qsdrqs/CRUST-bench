use crate::aes::{NB, NR};
pub fn columns(state: &mut [[u8; NB]; 4]) {
    unimplemented!()
}
pub fn inv_columns(state: &mut [[u8; NB]; 4]) {
    unimplemented!()
}