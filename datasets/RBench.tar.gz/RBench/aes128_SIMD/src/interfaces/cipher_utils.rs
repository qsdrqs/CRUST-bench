use crate::aes::{NB, NR};
pub fn g_mult(first: u8, second: u8) -> u8 {
    unimplemented!()
}
pub fn sub(state: &mut [[u8; NB]; 4]) {
    unimplemented!()
}
pub fn inv_sub(state: &mut [[u8; NB]; 4]) {
    unimplemented!()
}