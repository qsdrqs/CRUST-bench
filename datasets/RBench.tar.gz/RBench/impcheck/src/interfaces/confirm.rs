pub fn confirm_result(f_sig: &[u8], constant: u8, out: &mut [u8]) {
    unimplemented!()
}