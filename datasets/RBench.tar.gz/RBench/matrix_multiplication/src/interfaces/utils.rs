pub fn print_array(matrix: &[Vec<f32>], name: &str, typ: &str) -> i32 {
    unimplemented!()
}
pub fn print_float_array(matrix: &[Vec<f32>]) -> i32 {
    unimplemented!()
}