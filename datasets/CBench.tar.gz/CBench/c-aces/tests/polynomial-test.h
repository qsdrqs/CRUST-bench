#ifndef POLYNOMIAL_TEST_H
#define POLYNOMIAL_TEST_H

#ifdef __cplusplus
extern "C" {
#endif

int run_polynomial_tests();

#ifdef __cplusplus
}
#endif

#endif
