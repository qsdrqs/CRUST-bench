Contributios are welcome. here are some ways to contribute:

- Simplify the code
- Fix an issue that you faced while using the program
- Open an issue to suggest a feature and get initial thoughts before implementing it.


Contribution is as usual: Fork, Branch, Commit, Pull request.

Happy hacking.
