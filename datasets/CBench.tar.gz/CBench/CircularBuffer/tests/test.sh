gcc tests/test.c src/CircularBuffer.c -o test
./test