#if !defined DEFINES
#define DEFINES

#define COUNTOF(x) ((sizeof(x))/(sizeof(x[0])))

#endif /* !DEFINES */

