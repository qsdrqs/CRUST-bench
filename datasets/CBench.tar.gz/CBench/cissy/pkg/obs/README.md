Buildfiles for https://build.opensuse.org/project/show/home:slass100
