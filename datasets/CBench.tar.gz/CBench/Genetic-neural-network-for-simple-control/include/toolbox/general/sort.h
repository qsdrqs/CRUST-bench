#ifndef SORT_H
#define SORT_H

#include <stddef.h>

// function to sort and return indexesof values from max to min
void quickSort(float *fit, int *result, int length);
#endif