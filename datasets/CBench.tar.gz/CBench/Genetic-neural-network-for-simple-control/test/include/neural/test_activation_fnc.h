#ifndef TEST_ACTIVATION_FNC_H
#define TEST_ACTIVATION_FNC_H

int testActivationFncTanh();

int testActivationFncSigm();

#endif