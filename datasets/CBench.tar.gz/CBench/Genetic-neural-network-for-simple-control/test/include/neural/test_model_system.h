#ifndef TEST_MODEL_SYSTEM_H
#define TEST_MODEL_SYSTEM_H

// function to test if the create system model works
int testSystemCreate();

#endif