#ifndef TEST_SYSTEM_BUILDER_H
#define TEST_SYSTEM_BUILDER_H

// function to test the select of system
int testSelectSystem();

#endif