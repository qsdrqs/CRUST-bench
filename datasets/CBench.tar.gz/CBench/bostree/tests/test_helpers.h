#include "../bostree.h"

void test_tree_sanity(BOSTree *tree);
